""" Fishing.py by Dante Pallone and Sam Blehm

    Dante's Hours
    11-25-22 2 hours created fish picker(lost due to save error)
    12-5-22 - 1 hour recreated fish picker(saved this time)
    12-7-22 - 3 hours cleared backgrounds on images and chased bugs
    12-8-22 - 4 hours banged head aganst slider bug (painful) and some graphic fixes
    12-9-22 - 1 hour fixed slider bug(major)
    12-11-22 - 1 hour polished game, boat mechanics, turned in
    total -12 hours
    
    Sams Hours
    11-25-22 - 2 hours drafting, making graphics
    12-2-22 - 3 hours wrote simulator components, also wrote graphic components
    12-3-22 - 6 hours combined components, created tons of bugs for dante
    12-5-22 - 1 hour edited graphics, tweaked game
    12-9-22 - 1 hour tweaked buttons and slider
    12-11-22 - 1 hour polished game, boat mechanics, turned in
    total - 14 hours
"""
    
from tkinter import *

stop = False
carp1 = ""
def sliderbounce(m,y):

    global stop
    global x0
    global y0
    global x1
    global y1
    try:
        x0,y0,x1,y1 = canvas.coords(square) 
        if x1 >=510:
            m = -5
        elif x0 <=90:
            m = 5
       
    
        root.after(30,sliderbounce,m,0)
    
        canvas.move(square,m,0)
    except Exception :
        print('')
def chillout(event):
    print('you have to attract a fish first')
   
def slidercollision(event):
    #print('mouse pressed at : (%d, %d)' % (event.x, event.y))
    stop = True
    global x0
    global y0
    global x1
    global y1
    canvas.bind("<space>", chillout)
    #bar = canvas.create_rectangle(282, 304, 321, 382, fill = "green")
    #canvas.tag_lower(bar)
    #canvas.tag_lower(bar)
    cx0,cy0,cx1,cy1 = canvas.coords(bar)
    if cx0 <= x0 and cx1 >= x1:
        print("fish has been caught")
        #catch_fish()
        fx()
        catch_fish()
        #reelbutton.pack_forget()
    else:
        print("miss")
        keepbutton.pack_forget()
        sellbutton.pack_forget()
        lurebutton.pack_forget()
        boatbutton.pack_forget()
        #freelbutton.pack_forget()
        fx()
        
        
        #print(str(x0),str(y0),str(x1),str(y1))






import random
root = Tk()
root.geometry("700x500")
#creates canvas
canvas = Canvas(root, width=600, height=400, bg = 'white')
canvas.pack()
weight = 0

#square = canvas.create_rectangle(15,300,30,385, fill = "blue")

#canvas.bind("<Button-1>", slidercollision)
#canvas.focus_set()





moneycounter = 0




slider = 25
#20-30 is in green for testing

fishon_bool = False
#default = False until fish on line

fishcaught_bool = False
#default = False until user clicks in green (wins minigame)


fish = "Trout"
    #pulls fishtype from .txt file

caughtfish = 0

keptfish = []

def catch_fish():
    global carp1
    global caughtfish
    global weight
    global lurevalue
    global fish
    
    global carp_img
    global rainbowtrout_img
    global laketrout_img
    global brooktrout_img
    global largemouthbass_img
    global smallmouthbass_img
    global browntrout_img
    global yellowperch_img
    global sunfish_img
    global nessi_img
    
    
    
    f = open('fishlist.txt')
    list = f.readlines()
    fish = random.choice(list)
    if lurevalue ==1 :
        weight = round(random.uniform(0.2,5.0),2)
    elif lurevalue == 2:
        weight = round(random.uniform(3.0,7.0),2)
    elif lurevalue == 3:
        weight = round(random.uniform(7.0,15.0),2)
    print("you caught a " + fish)
    print('your fish weighs ' + str(weight) + ' pounds')
    
    if "carp" in fish:
        carp1 = canvas.create_image(265,70, anchor = NW, image=carp_img)
    if "rainbow" in fish:
        carp1 = canvas.create_image(265,82, anchor = NW, image=rainbowtrout_img)
    if "lake" in fish:
        carp1 = canvas.create_image(265,77, anchor = NW, image=laketrout_img)
    if "brook" in fish:
        carp1 = canvas.create_image(265,82, anchor = NW, image=brooktrout_img)
    if "largemouth" in fish:
        carp1 = canvas.create_image(265,80, anchor = NW, image= largemouthbass_img)
    if "smallmouth" in fish:
        carp1 = canvas.create_image(265,80, anchor = NW, image=smallmouthbass_img)
    if "sunfish" in fish:
        carp1 = canvas.create_image(265,72, anchor = NW, image=sunfish_img)
    if "lochness monster" in fish:
        carp1 = canvas.create_image(245,85, anchor = NW, image=nessi_img)
    if "brown" in fish:
        carp1 = canvas.create_image(265,75, anchor = NW, image=browntrout_img)
    if "yellow" in fish:
        carp1 = canvas.create_image(265,75, anchor = NW, image=yellowperch_img)
        
    caughtfish += 1
    lurebutton.pack()
            
    sellbutton.pack()
            
    keepbutton.pack()
      
    boatbutton.pack()
    f.close()
    
    
    #keeporsell = "na"
    #print("I caught a " + str(weight) + ' pound ' + str(fish) + "!")
def deletefish():
    global carp1
    canvas.delete(carp1)

    
def fishon_def():
    global event
    global caughtfish
    global lurebutton
    
    print("Somethings on my line!")
    
    root.after(17,sliderbounce,5,0)
        #call slider function here
    #reelbutton = Button(root, text= 'Snag Fish', command = slidercollision)
    #reelbutton.pack()
    
    
    canvas.bind("<space>", slidercollision)
    
    canvas.focus_set()
    """
    if slider in range(20, 30):
            #fish caught
        catch_fish()
        keeporsell = "na"
        print("I caught a " + str(weight) + ' pound ' + str(fish) + "!")
    
        caughtfish += 1
        lurebutton.pack()
            
        sellbutton.pack()
            
        keepbutton.pack()
    """
            #keeporsell = input("Would you like to keep this fish or sell?")
    """
            lurebutton = Button(root, text= 'lure', command = lure_def)
            lurebutton.pack()
            sellbutton = Button(root, text= 'sell', command = sell_def)
            sellbutton.pack()
            keepbutton = Button(root, text= 'keep', command = keep_def)
            keepbutton.pack()
    """
            
        
            
            #if keeporsell == "lure":
                #lure_def()
            #if "keep" in keeporsell:
                
                
            #if "sell" in keeporsell:
                #print("sellfish")
                    #add to money counter
                
                #g = 25/weight
                #moneycounter = moneycounter + g
                
                
                #(int(weight)/13)
                    
        
def keep_def():
    """
    global canvas
    global keepbutton
    """
    global keptfish
    print("keepfish")
                    #add to list of caught fish
    
    keptfish.append(fish)
    keptfish1 = [item.strip() for item in keptfish]
    print('Trophy List ')
    print(keptfish1)
    keepbutton.pack_forget()
    sellbutton.pack_forget()
def sell_def():
    """
    global canvas
    global sellbutton
    """
    global moneycounter
    
    print("sellfish")
                    #add to money counter   
    g = weight/2.5
    moneycounter = moneycounter + g
    print("You have $" + str(round(moneycounter,2)))
    sellbutton.pack_forget()
    keepbutton.pack_forget()
    
lurevalue = 1
lure_buy = True
def lure_def():
#lurebuy true = click buy lure
    #lurevalue of 1 is bad, 2 is better, 3 is best
    global moneycounter
    global lure_buy
    global lurevalue
    global lure2
    global lure3
    global lure1
    """
    global lurebutton
    global canvas
    """
    
    if lure_buy == True:
        if moneycounter >= 10 and lurevalue < 3:
            lurevalue +=1
            moneycounter -= 10
            print("you have upgraded a lure")
        if lurevalue == 2:
            canvas.delete(lure1)
            lure2 = canvas.create_image(265,70, anchor = NW, image=lure2_img)
        if lurevalue == 3:
            canvas.delete(lure2)
            lure3 = canvas.create_image(265,70, anchor = NW, image=lure3_img)
        #switch lures (open second sheet with beter values)
        
        
        if moneycounter < 10 or lurevalue == 3  :
            print("you cannot buy the next lure")
    lurebutton.pack_forget()
    return lurevalue
       
#i = 0
#while i <= 5:
    
   # fishon_def()
    
   # print(keptfish)
    #print("$" + str(moneycounter))
boat = False 
def boat_def():
    global boat
    global moneycounter
    if moneycounter >= 30:
            boat = True
            moneycounter -=30 
            print("You have Purchased a Boat")
    else:
        print('You Cannot Afford a Boat')
    

lurebutton = Button(root, text= 'Upgrade lure ($10)', command = lure_def)
lurebutton.pack_forget()
sellbutton = Button(root, text= 'Sell Fish', command = sell_def)
sellbutton.pack_forget()
keepbutton = Button(root, text= 'Keep Fish', command = keep_def)
keepbutton.pack_forget()
boatbutton = Button(root, text= 'Buy Boat ($30)', command = boat_def)
boatbutton.pack_forget()
canvas.pack(fill= "both", expand=True)

#reelbutton = Button(root, text= 'Snag Fish', command = slidercollision)
#reelbutton.pack_forget()

#image imports
fishcaught_img = PhotoImage(file="fishing_guy.png")
fishon_img = PhotoImage(file="fishing_guy_nofish.png")
sliderbar_img = PhotoImage(file="sliderbar.png")
lure1_img = PhotoImage(file="lure1.png")
lure2_img = PhotoImage(file="lure2.png")
lure3_img = PhotoImage(file="lure3.png")
#adds images to canvas



#fishimages
carp_img = PhotoImage(file="carp.png")
browntrout_img = PhotoImage(file="browntrout.png")
rainbowtrout_img = PhotoImage(file="rainbow_trout.png")
brooktrout_img = PhotoImage(file="brooktrout.png")
laketrout_img = PhotoImage(file="laketrout.png")
largemouthbass_img = PhotoImage(file="largemouthbass.png")
smallmouthbass_img = PhotoImage(file="smallmouthbass.png")
yellowperch_img = PhotoImage(file="yellowperch.png")
sunfish_img = PhotoImage(file="sunfish.png")
nessi_img = PhotoImage(file="nessi.png")
boat_img = PhotoImage(file="boat.png")

bar = canvas.create_rectangle(282, 304, 321, 382, fill = "green")
canvas.tag_lower(bar)
canvas.tag_lower(bar)
sliderbar = canvas.create_image(80,300, anchor = NW, image=sliderbar_img)
fishing = canvas.create_image(50,0, anchor = NW, image=fishcaught_img)
fishon = canvas.create_image(50,0, anchor = NW, image=fishon_img)
canvas.delete(fishing)
#square = canvas.create_rectangle(85,304,100,382, fill = "blue")
#bar1 = canvas.create_rectangle(282, 304, 321, 382, fill = "yellow")
lure1 = canvas.create_image(240,75, anchor = NW, image=lure1_img)

a = 0


#import background
background_img = PhotoImage(file="background.png")
boat1 = canvas.create_image(5000,8000, anchor = NW, image = boat_img)
    

def fx():
    global stop
    global fishon
    global fishing
    global a
    global square
    global x0
    global y0
    global x1
    global y1
    global boat
    global boat1
    #global uses value outside of def, could not make return work
    
    
    #this works but not in if statements
    
    
    a = a+1
    if a % 2 != 0 :
        canvas.delete(fishon)
        if boat == True:
            canvas.delete(boat1)
        square = canvas.create_rectangle(85,304,100,382, fill = "blue")
        x0,y0,x1,y1 = canvas.coords(square)  
        stop = False
        if a > 2:
            deletefish()
        
        #need to replace corresponding picture
        
        fishing = canvas.create_image(50,0, anchor = NW, image=fishcaught_img)
        if boat == True:
            boat1 = canvas.create_image(50,80, anchor = NW, image = boat_img)
        fishon_def()
    if a % 2 == 0:
        #reelbutton.pack_forget()
        canvas.delete(fishing)
        if boat == True:
            canvas.delete(boat1)
        #need to replace corresponding picture
        
        fishon = canvas.create_image(50,0, anchor = NW, image=fishon_img)
        if boat == True:
            boat1 = canvas.create_image(50,80, anchor = NW, image = boat_img)
        x0,y0,x1,y1 = canvas.coords(square)  
        canvas.delete(square)
          
        #fishon_bool == True
        
        
    
        
        
#why wont these print
    #print('click')
    #print(str(a))
    
#

      
button = Button(root, text= 'Attract a Fish', command = fx)
button.pack()









root.mainloop()
